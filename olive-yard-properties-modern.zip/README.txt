OLIVE YARD PROPERTIES — MODERN DEMO WEBSITE

Open index.html in a browser, or upload the folder contents to GitHub Pages / Netlify / Vercel.

Notes:
- Property listings, team members, prices and contact details are fictional template/demo content.
- Images are loaded from Unsplash URLs.
- The contact form is front-end demo only; connect it to a form provider or backend before launch.
